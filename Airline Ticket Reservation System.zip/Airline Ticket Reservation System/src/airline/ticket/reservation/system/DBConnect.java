/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airline.ticket.reservation.system;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author MAK
 */
public class DBConnect {
    private Connection con;
    private Statement st;
    private ResultSet rs;
    public DBConnect(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        //step1 : get connection to Db
        con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/projectdatabase","root","");
        System.out.println("DB Connection Successful");
        //step-2: Create a statement
        st=con.createStatement();
    }
    catch(Exception e){
        System.out.println("Error: "+e);
     //   e.printStackTrace();
    }
    }
    public DBConnect(String url, String user, String password) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            //Step-1: get a connection to the db
            con = DriverManager.getConnection(url, user, password);
            //Step-2: create a statement
            st = con.createStatement();
        } catch (Exception e) {
            System.out.println("Error: " + e);
            e.printStackTrace();
        }
    }
    public ResultSet getResultSet() {
        try {
            String query = "SELECT `Customer_ID`, `First_Name`, `Last_Name`, `Passport_No`, `Date_of_Birth`, `Gender`, `Address`, `Email`, `Contact_No` FROM `customerinfo` ";
            //Step-3: Execute SQL query
            rs = st.executeQuery(query);
        } catch (Exception e) {
            System.out.println("Error: " + e);
            e.printStackTrace();
        }
        return rs;
    }
    public ResultSet getResultSet1() {
        try {
            String query = "SELECT `Flight_ID`, `Source`, `Destination`, `Departure`, `Company`, `Class`, `Price` FROM `flight`";
            //Step-3: Execute SQL query
            rs = st.executeQuery(query);
        } catch (Exception e) {
            System.out.println("Error: " + e);
            e.printStackTrace();
        }
        return rs;
    }
    public ResultSet getResultSet2() {
        try {
            String query = "SELECT `Flight_ID`, `Customer_ID`, `Payment_Method`, `Amount`,`Date` FROM `reserved`";
            //Step-3: Execute SQL query
            rs = st.executeQuery(query);
        } catch (Exception e) {
            System.out.println("Error: " + e);
            e.printStackTrace();
        }
        return rs;
    }
    public void insertIntoDB(ArrayList row) {
        try {
            String query = "insert into customerinfo(First_Name, Last_Name, Passport_No, Date_of_Birth, Gender ,Address ,Email, Contact_No) values('" + row.get(0) + "','" + row.get(1) +"','"+ row.get(2)+"','"+ row.get(3)+"','"+ row.get(4)+"','"+ row.get(5)+"','"+ row.get(6)+"','"+ row.get(7)+"');";
            System.out.println(query);
            //Step-3: Execute SQL query
            st.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Customer Info Added Successfully.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Insert into Database Exception: " + e);
            System.out.println(e);
        }
         
    }
    public void insertIntoDB1(ArrayList row) {
        try {
            String query = "insert into flight(Source, Destination, Departure, Company, Class ,Price ) values('" + row.get(0) + "','" + row.get(1) +"','"+ row.get(2)+"','"+ row.get(3)+"','"+ row.get(4)+"','"+ row.get(5)+"');";
            System.out.println(query);
            //Step-3: Execute SQL query
            st.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Flight Info Added Successfully.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Flight wasn't added,Please try again " + e);
            System.out.println(e);
        }
         
    }
    public void insertIntoDB2(ArrayList row) {
        try {
            String query = "insert into reserved(Flight_ID, Customer_ID, Payment_Method, Amount,Date ) values('" + row.get(0)+ "','" + row.get(1)  + "','" + row.get(2) +"','"+ row.get(3)+"','"+ row.get(4)+"');";
            System.out.println(query);
            //Step-3: Execute SQL query
            st.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Reserved Flight Info Added Successfully.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ticket wasn't reserved,Please try again" + e);
            System.out.println(e);
        }
         
    }
    public void deleteFromDB(int id){
        try{
            String query="delete from customerinfo where Customer_ID='"+id+"'";
            st.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Selected Customer info deleted successfully");
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Selected Customer wasn't deleted" + e);
            System.out.println(e);
        }
    }
    public void deleteFromDB1(int id){
        try{
            String query="delete from flight where Flight_ID='"+id+"'";
            st.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Selected Flight info deleted successfully");
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Selected flight wasn't removed" + e);
            System.out.println(e);
        }
    }
    
        
    public void insert(int id){
        try{
            String query="select Flight_ID from flight where Flight_ID='"+id+"'";
            st.executeUpdate(query);
            //JOptionPane.showMessageDialog(null, "Selected Customer info deleted successfully");
        }catch(SQLException e){
            //JOptionPane.showMessageDialog(null, "Delete From Database Exception: " + e);
            System.out.println(e);
        }
    }
        
}
