/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airline.ticket.reservation.system;

/**
 *
 * @author MAK
 */
public class AirlineTicketReservationSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        selectuserFrame frameD= new selectuserFrame();
        frameD.setDefaultCloseOperation(frameD.DISPOSE_ON_CLOSE);
        
        
        UserloginFrame frameA=new UserloginFrame();
        frameA.setDefaultCloseOperation(frameA.DISPOSE_ON_CLOSE);
        
         
        SystemloggedinFrame frameB = new SystemloggedinFrame();
        frameB.setDefaultCloseOperation(frameB.DISPOSE_ON_CLOSE);
       
        AddNewCustomerFrame frameC= new AddNewCustomerFrame();
        frameC.setDefaultCloseOperation(frameC.DISPOSE_ON_CLOSE);
        
        frameD.setVisible(true);
        frameD.setLocation(500,300);
        
        //DBConnect connect = new DBConnect();
        
    }
    
}
